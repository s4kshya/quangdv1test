﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Umbraco.Cms.Web;

[assembly: AssemblyTitle("Umbraco.Cms.Web.PropertyEditors")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("1fae275d-95b1-4a16-8af1-ed7cdab30461")]

//Mark this assembly as exported as a PropertyEditorPlugin
[assembly: AssemblyContainsPlugins()]
