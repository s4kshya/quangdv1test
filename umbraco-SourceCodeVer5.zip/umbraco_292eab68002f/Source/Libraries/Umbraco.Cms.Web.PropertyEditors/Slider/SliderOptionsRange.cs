﻿using System;
using System.ComponentModel;

namespace Umbraco.Cms.Web.PropertyEditors.Slider
{
	public enum SliderOptionsRange
	{
		None,

		Min,

		Max
	}
}
