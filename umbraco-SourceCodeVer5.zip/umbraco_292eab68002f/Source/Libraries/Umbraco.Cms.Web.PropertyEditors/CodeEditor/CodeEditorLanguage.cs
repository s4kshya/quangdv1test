﻿namespace Umbraco.Cms.Web.PropertyEditors.CodeEditor
{
    public enum CodeEditorLanguage
    {
        JavaScript, Css, Xml
    }
}