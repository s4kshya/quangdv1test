﻿using System.Reflection;
using System.Runtime.InteropServices;
using Umbraco.Cms.Web;

[assembly: AssemblyTitle("Umbraco.Cms.Web.Editors")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("51aeac11-bd2d-4bd4-9b2a-65e114481db9")]

[assembly: AssemblyContainsPlugins]