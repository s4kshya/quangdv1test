﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Umbraco.Cms.Web;

[assembly: AssemblyTitle("Umbraco.Cms.Packages.SystemInfo")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b57a436b-eaf9-4fab-a776-45d26cd14729")]

//mark assembly for export
[assembly: AssemblyContainsPlugins]