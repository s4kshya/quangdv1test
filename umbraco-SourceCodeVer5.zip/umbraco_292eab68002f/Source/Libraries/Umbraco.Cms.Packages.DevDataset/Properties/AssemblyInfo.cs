﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Umbraco.Cms.Web;

[assembly: AssemblyTitle("Umbraco.Cms.Packages.DevDataset")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c2d4d369-766c-4c9d-a82c-b4c4628b42d9")]

[assembly: InternalsVisibleTo("Umbraco.Tests.DomainDesign")]

//advertise that this assembly contains tasks
[assembly: AssemblyContainsPlugins]