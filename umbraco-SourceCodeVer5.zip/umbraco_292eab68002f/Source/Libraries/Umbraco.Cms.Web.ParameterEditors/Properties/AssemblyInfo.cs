﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Umbraco.Cms.Web;

[assembly: AssemblyTitle("Umbraco.Cms.Web.ParameterEditors")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("B16EF6E1-2147-44B9-9A3D-8EBCB1822C65")]

//Mark this assembly as exported as a PropertyEditorPlugin
[assembly: AssemblyContainsPlugins()]
