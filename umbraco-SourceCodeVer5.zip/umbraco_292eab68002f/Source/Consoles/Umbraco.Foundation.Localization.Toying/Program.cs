﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Umbraco.Foundation.Localization.Toying
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
