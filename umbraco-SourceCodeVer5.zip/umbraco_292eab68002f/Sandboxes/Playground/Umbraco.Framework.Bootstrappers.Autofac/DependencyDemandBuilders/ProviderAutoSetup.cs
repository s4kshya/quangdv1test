﻿using System;
using Umbraco.Foundation;
using Umbraco.Framework.DependencyManagement;

namespace Umbraco.Framework.Bootstrappers.Autofac.DependencyDemandBuilders
{
	public class ProviderAutoSetup : IDependencyDemandBuilder
	{
        public void Build(IContainerBuilder containerBuilder, IBuilderContext builderContext)
		{
			//TODO: Move code from the Autofac module "ProviderAutoSetup"
			throw new NotImplementedException();
		}
	}
}