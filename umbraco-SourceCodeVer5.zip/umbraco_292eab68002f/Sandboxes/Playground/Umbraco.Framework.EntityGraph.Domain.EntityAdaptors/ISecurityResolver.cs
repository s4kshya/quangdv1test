﻿namespace Umbraco.Framework.EntityGraph.Domain.EntityAdaptors
{
    public interface ISecurityResolver
    {
    }
}