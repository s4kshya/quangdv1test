﻿using Umbraco.Framework.EntityGraph.Domain.Entity;

namespace Umbraco.Framework.EntityGraph.Domain.EntityAdaptors
{
    public interface IContentEntity : ITypedEntity
    {
    }
}
