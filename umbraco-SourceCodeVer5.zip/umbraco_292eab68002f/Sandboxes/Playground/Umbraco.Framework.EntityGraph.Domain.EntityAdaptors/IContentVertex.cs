﻿using Umbraco.Framework.EntityGraph.Domain.Entity.Graph;

namespace Umbraco.Framework.EntityGraph.Domain.EntityAdaptors
{
    public interface IContentVertex : ITypedEntityVertexAdaptor<IContentVertex>
    {
    }
}