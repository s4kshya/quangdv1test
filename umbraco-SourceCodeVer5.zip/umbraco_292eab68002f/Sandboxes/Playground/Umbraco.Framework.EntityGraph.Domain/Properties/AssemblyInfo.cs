﻿using System.Reflection;
using System.Runtime.CompilerServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Umbraco.Framework.EntityGraph.Domain")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

[assembly: InternalsVisibleTo("Umbraco.Framework.EntityGraph.Domain.Tests")]
[assembly: InternalsVisibleTo("Umbraco.Framework.EntityGraph.Domain.Explorables")]
[assembly: InternalsVisibleTo("Umbraco.CMS.DataPersistence")]