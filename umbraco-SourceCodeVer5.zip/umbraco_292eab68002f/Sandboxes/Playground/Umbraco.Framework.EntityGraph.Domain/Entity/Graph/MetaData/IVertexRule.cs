﻿namespace Umbraco.Framework.EntityGraph.Domain.Entity.Graph.MetaData
{
    /// <summary>
    /// Provides a determination of allowed descendent vertices
    /// </summary>
    public interface IVertexRule
    {
    }
}