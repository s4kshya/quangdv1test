﻿using Umbraco.Framework.EntityGraph.Domain.ObjectModel;

namespace Umbraco.Framework.EntityGraph.Domain.Entity.Graph
{
    //TODO: What is this class for?
    public class EntityAssociationCollection : EntityCollection<IEntityAssociation>, IEntityAssociationCollection
    {
        //protected EntityAssociationCollection()
        //{
        //}

        //public EntityAssociationCollection(IEnumerable<IEntityAssociation> incoming)
        //    : base(incoming)
        //{
        //}
    }
}