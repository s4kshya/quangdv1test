﻿namespace Umbraco.Framework.EntityGraph.Domain.Entity
{
    /// <summary>
    ///   Represents the status of an entity
    /// </summary>
    public interface IEntityStatus : IReferenceByAlias
    {
    }
}