using System.Collections.Generic;

namespace Umbraco.Framework.EntityGraph.Domain.Entity.Attribution
{
    public interface IAttributeGroupCollection : IList<IAttributeGroup>
    {
    }
}