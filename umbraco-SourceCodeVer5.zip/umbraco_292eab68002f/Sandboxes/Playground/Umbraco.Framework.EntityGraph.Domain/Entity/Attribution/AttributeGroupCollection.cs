﻿using Umbraco.Framework.EntityGraph.Domain.ObjectModel;

namespace Umbraco.Framework.EntityGraph.Domain.Entity.Attribution
{
    public class AttributeGroupCollection : EntityCollection<IAttributeGroup>, IAttributeGroupCollection
    {
       
    }
}