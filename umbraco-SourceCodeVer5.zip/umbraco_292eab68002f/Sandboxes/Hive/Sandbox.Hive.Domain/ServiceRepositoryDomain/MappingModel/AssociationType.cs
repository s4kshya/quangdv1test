﻿namespace Sandbox.Hive.Domain.ServiceRepositoryDomain.MappingModel
{
  public enum AssociationType
  {
    Hierarchy,
    Permission
  }
}