﻿namespace Sandbox.Hive.Foundation
{
  public static class DependencyResolver
  {
    public static IDependencyResolver Current { get; set; }
  }
}