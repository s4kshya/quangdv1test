﻿namespace Sandbox.Hive.Foundation
{
  public interface IProviderSetupModule
  {
    string Alias { get; set; }
  }
}